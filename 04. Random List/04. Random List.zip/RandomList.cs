﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04._Random_List
{
    class RandomList
    {
    }
}
