﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    class Dog:Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking");
        }
    }
}
